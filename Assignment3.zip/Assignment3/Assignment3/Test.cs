﻿using System;
using System.Collections.Generic;

namespace Filesystem
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    #region Node
    /// <summary>
    /// 
    /// </summary>
    class Node
    {
        #region field/properties
        private string directory;   // directory name 
        private List<string> file;  // files in the directory
        private Node leftMostChild; // left most child of the directory structure
        private Node rightSibling;  // directories on the same level
        #endregion

        #region getters & setters
        public string Directory
        {
            get => directory;
            set => directory = value;
        }
        public List<string> File
        {
            get => file;
            set => file = value;
        }
        public Node LeftMostChild
        {
            get => leftMostChild;
            set => leftMostChild = value;
        }
        public Node RightSibling
        {
            get => rightSibling;
            set => rightSibling = value;
        }
        #endregion

        #region Constructor
        public Node(string directory, Node leftMostChild, Node rightSibling)
        {
            this.directory = directory;
            this.leftMostChild = leftMostChild;
            this.rightSibling = rightSibling;
            this.file = new List<string>();
        }
        #endregion

    }
    #endregion
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    #region
    /// <summary>
    /// 
    /// </summary>
    public class FileSystem
    {
        //filed
        private Node root;

        #region Constructor
        //creates a file system with a root directory
        public FileSystem()
        {
            root = new Node("/", null, null); // creates a root with 
        }
        #endregion

        #region Method AddFile
        //method name: AddFile
        //parameters: string address
        //return: bool
        //description: method takes string address, then adds the file at the given address
        //             if file already exists or the path is undefined returns false or else true.
        //steps:
        //    1. split the address and store in path array
        //    2. traverse through the tree / file system to get to the correct location
        //         - if path not found or does not exist return false
        //    3. at the location check if the current file exist
        //        - add if it does not and return true
        //        - else do not add and return false
        public bool AddFile(string address)
        {
            bool success = false;             //success set to false if added then set to true
            string[] path = address.Split('/');  //split the address
            string fileName = path[path.Length - 1]; // directory name to be added
            Node current = root;                 //reference to the root


            //navigate through the path to get to the location to add the file
            for (int i = 1; i < path.Length - 1; i++)
            {
                current = current.LeftMostChild; //leftmost child

                //traverse through the right subtree of this level
                //break the loop if current is null or current has same name as the path[i]
                while (current != null && current.Directory.CompareTo(path[i]) != 0)
                    current = current.RightSibling; //next sibling

                //if the path undefined or not found
                if (current == null)
                    return success;
            }

            //check if the directory contains the file
            if (current.File.Contains(fileName))
                Console.WriteLine("The file already exists"); //file already exists
            else
            {
                current.File.Add(fileName);
                success = true;
            }


            return success;
        }
        #endregion

        #region Method RemoveFile
        //method name: RemoveFile
        //parameters: string address
        //return: bool
        //description: method takes string address, then removes the file at the given address
        //             if file not found or the path is undefined returns false or else true.
        //steps:
        //    1. split the address and store in path array
        //    2. traverse through the tree / file system to get to the correct location
        //         - if path not found or does not exist return false
        //    3. at the location check if the current file exist
        //        - remove if it  exist and return true
        //        - else return false
        public bool RemoveFile(string address)
        {
            bool success = false;
            string[] path = address.Split('/');
            string fileName = path[path.Length - 1]; // directory name to be removed
            Node current = root;                 //reference to the root


            //navigate through the path to get to the location to remove the file
            for (int i = 1; i < path.Length - 1; i++)
            {
                current = current.LeftMostChild; //leftmost child

                //traverse through the right subtree of this level
                //break the loop if current is null or current has same name as the path[i]
                while (current != null && current.Directory.CompareTo(path[i]) != 0)
                    current = current.RightSibling; //next sibling

                //if the path undefined or not found
                if (current == null)
                    return success;
            }

            //check if the directory contains the file
            if (current.File.Contains(fileName))
            {
                current.File.Remove(fileName); //remove
                success = true;
            }
            else
                Console.WriteLine("The file already exists");  //file does not exist


            return success;
        }
        #endregion

        #region Method AddDirectory
        //method name: AddDirectory
        //parameters: string address
        //return: bool
        //description: method takes string address, then adds the directory at the given address
        //             if directory already exists or the path is undefined returns false or else true.
        // steps: 
        //          1. split the address and store it in an array path
        //          2. traverse through the path given to get to the location for adding directory
        //               - if path undefined or not found return false
        //          3. check if the directory already exist at the location
        //              - return false if exists
        //          4. add if it does not exist and return true
        public bool AddDirectory(string address)
        {
            bool success = false;             //success set to false if added then set to true
            string[] path = address.Split('/');  //split the address
            string directoryName = path[path.Length - 1]; // directory name to be added
            Node current = root;                 //reference to the root
            Node location = root, previous = root;

            //navigate through the path to get to the location to add directory
            for (int i = 1; i < path.Length - 1; i++)
            {
                current = current.LeftMostChild; //leftmost child

                //traverse through the right subtree of this level
                //break the loop if current is null or current has same name as the path[i]
                while (current != null && current.Directory.CompareTo(path[i]) != 0)
                    current = current.RightSibling; //next sibling

                //if the path undefined or not found
                if (current == null)
                    return success;
            }

            //check if the directory already exists 
            location = current;
            if (location.LeftMostChild == null) //if leftmost child is null then the new directory becomes leftmost child
            {
                location.LeftMostChild = new Node(directoryName, null, null);
                success = true;         //set it to true
            }
            else // else check if the directory already exists
            {
                location = location.LeftMostChild;    //traverse and check if it already exists

                while (location != null && location.Directory.CompareTo(directoryName) != 0) //break the while loop if directory exists or if it does not exist
                {
                    previous = location;  //previous sibling
                    location = location.RightSibling; //next sibling
                }
                //add if it does not exist
                if (location == null)
                {
                    location = previous;
                    location.RightSibling = new Node(directoryName, null, null);
                    success = true;
                }
                else //throw an error
                {
                    Console.WriteLine("Directory already exists..");
                }
            }

            return success; //return true or false
        }
        #endregion

        #region Method RemoveDirectory
        //method name: RemoveDirectory
        //parameters: string address
        //return: bool
        //description: method takes string address, then removes the directory at the given address
        //             if directory not found or the path is undefined returns false or else true.
        public bool RemoveDirectory(string address)
        {
            bool success = false;
            string[] path = address.Split('/');
            string directoryName = path[path.Length - 1]; // directory name to be removed
            Node current = root;                 //reference to the root
            Node previous = root;                //previous node

            //if deleting the root 
            if (address.Equals("/"))
            {
                Console.WriteLine("You cannot delete the root");
                return success;
            }

            //navigate through the path to get to the location of directory to be removed
            for (int i = 1; i < path.Length - 1; i++)
            {
                previous = current;
                current = current.LeftMostChild; //leftmost child


                //traverse through the right subtree of this level
                //break the loop if current is null or current has same name as the path[i]
                while (current != null && current.Directory.CompareTo(path[i]) != 0)
                {
                    previous = current;
                    current = current.RightSibling; //next sibling
                }

                //if the path undefined or not found
                if (current == null)
                    return success;
            }

            // delete the directory at the correct location
            if (current.LeftMostChild != null && current.LeftMostChild.Directory.CompareTo(directoryName) == 0) //if it is leftmost child
            {
                current.LeftMostChild = current.LeftMostChild.RightSibling;
                success = true;
            }
            else //if not leftmost child
            {
                previous = current;
                current = current.LeftMostChild;

                while (current != null && current.Directory.CompareTo(directoryName) != 0)  //find the directory in right subtree
                {
                    previous = current;
                    current = current.RightSibling; // next right sibling
                }

                if (current != null) //when the correct directory is found
                {
                    current = previous;
                    current.RightSibling = current.RightSibling.RightSibling;     //remove the directory
                    success = true;
                }
                else            //if the path does not exist
                    Console.WriteLine("The directory by the name {0} does not exist", directoryName);
            }


            return success;
        }
        #endregion

        #region Method NumberFiles
        //method name: NumberFiles
        //parameters: void
        //return: int
        //description: the method returns the total number of files
        //steps:
        //    1. traverse through the file system
        //    2. get number of files in each directory
        //    3. sum the totals 
        //    4. return the totals
        public int NumberFiles()
        {
            int totalFiles = 0;
            Node current = root; // reference to the root

            //invoke the local method
            countFiles(current);

            //recursive method that traverses all the filesyste
            void countFiles(Node currentt)
            {
                if (current == null)
                    return;              //stop if current is null
                else
                {
                    totalFiles += current.File.Count;        //add number of file in the directory to the totalFiles

                    if (current.RightSibling != null) //go to each rightsibling
                        countFiles(current.RightSibling);
                    if (current.LeftMostChild != null) //go to each leftmost child
                        countFiles(current.LeftMostChild);
                }
            }

            return totalFiles;
        }
        #endregion

        #region Method PrintFileSystem
        // method name: PrintFileSystem
        // parameters: void
        // return: void
        // description: prints the directories and fill in pre-order.
        // steps:
        //     1. invoke the local method print 
        //     2. it recursively traverses through the filesystem
        //     3. and prints all directories and files
        public void PrintFilesSystem()
        {
            Node current = root; // reference of the root

            //invoke the local method and pass the root to it
            print(current);

            //recursive local method that prints out all the files and directories
            void print(Node currentt)
            {
                if (current == null)
                    return;              //stop if current is null
                else
                {
                    Console.WriteLine("{0}: ", current.Directory);        //print the directory
                    for (int i = 0; i < current.File.Count; i++)
                        Console.WriteLine("{0}. {1}", i + 1, current.File[i]); //all the files in the directory

                    if (current.RightSibling != null) //go to each rightsibling
                        print(current.RightSibling);
                    if (current.LeftMostChild != null) //go to each leftmost child
                        print(current.LeftMostChild);
                }
            }

        }
        #endregion
    }
    #endregion
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Class name: Test
    /// Description: 
    /// </summary>
    class Test
    {
        static void Main(string[] args)
        {
            int input = 0; // user input
            //instance of FileSystem
            FileSystem filesystem = new FileSystem();

            do
            {
                do
                {
                    Console.WriteLine("Menu for the filesystem(int only for input): ");
                    Console.WriteLine("1. Add directory to the filesystem.");
                    Console.WriteLine("2. Add a file.");
                    Console.WriteLine("3. Remove a directory.");
                    Console.WriteLine("4. Remove a file");
                    Console.WriteLine("5. print number of files in the filesystem.");
                    Console.WriteLine("6. Print all the directories and files in Pre-order.");
                    Console.WriteLine("7. Exit the program.");

                    Console.Write("Enter your option: ");
                    try
                    {
                        input = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {

                        Console.WriteLine("Wrong choice");
                    }

                } while (false);

                Console.WriteLine();
                switch (input)
                {
                    case 1:
                        Console.Write("Enter the address of the directory to be added starting from the root:(e.g /A/..) ");
                        string address = Convert.ToString(Console.ReadLine());
                        //add method
                        if (filesystem.AddDirectory(address) == true)
                            Console.WriteLine("Directory has been successfully added.");
                        else
                            Console.WriteLine("Add directory was unsuccessful");
                        break;
                    case 2:
                        Console.Write("Enter the address of the file to be added starting from the root: (e.g /A/..) ");
                        string fileAddress = Convert.ToString(Console.ReadLine());

                        //add file method
                        if (filesystem.AddFile(fileAddress) == true)
                            Console.WriteLine("file add successful");
                        else
                            Console.WriteLine("file add unsuccessful");
                        break;

                    case 3:
                        Console.Write("Enter the address of the directory to be removed starting from the root: (e.g /A/..) ");
                        string addressD = Convert.ToString(Console.ReadLine());

                        //remove directory method
                        if (filesystem.RemoveDirectory(addressD) == true)
                            Console.WriteLine("remove directory successful");
                        else
                            Console.WriteLine("remove directory unsuccessful");
                        break;

                    case 4:
                        Console.Write("Enter the address of the file to be removed starting from the root: (e.g /A/..) ");
                        string fileRemove = Convert.ToString(Console.ReadLine());

                        //remove file method
                        if (filesystem.RemoveFile(fileRemove) == true)
                            Console.WriteLine("File removed successfuly");
                        else
                            Console.WriteLine("File removal unsuccessful");
                        break;
                    case 5: //print number of files
                        Console.Write("Number of file in the filesystem are: " + filesystem.NumberFiles());
                        break;
                    case 6:   //print files and directories
                        Console.WriteLine("*** ALL THE DIRECTORIES AND FILES IN PRE-ORDER: ***");
                        filesystem.PrintFilesSystem();
                        break;
                    case 7: //stop the program
                        Console.WriteLine("******End of program******");
                        return;
                }
                Console.WriteLine();
            } while (true);



            //method that checks format of the string enteredd
        }
    }
}